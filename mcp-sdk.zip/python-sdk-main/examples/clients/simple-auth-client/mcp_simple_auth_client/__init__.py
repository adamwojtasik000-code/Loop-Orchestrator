"""Simple OAuth client for MCP simple-auth server."""
